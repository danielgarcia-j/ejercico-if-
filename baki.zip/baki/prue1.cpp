#include <iostream>
using namespace std;
int man (){
 int y ; 
 cout<<"ingrese su nota por favor "<<endl;
 cin>> y;

if (y>=90 && y<=100)
{
cout <<  y << "excelente" << endl; 
cout <<  y "sigue haci esforsandote" << endl; 
}
else if (y>=80&& y=<89)
{
cout <<  y "muy  bueno" << endl; 
cout <<  y "sigue haci esforsandote" << endl; 
}
elseif (y>=70&& y=<79)
{
cout <<  y " bueno" << endl; 
cout <<  y "sigue haci esforsandote" << endl; 
}
elseif ( y>=60&& y=<69)

{
cout <<  y "regular" << endl; 
cout <<  y "sigue haci esforsandote" << endl; 
}
elseif(y>=50&& y=<59)

{
cout <<  y "insuficiente" << endl; 
cout <<  y "sigue haci esforsandote" << endl; 
}
elseif(y>=0&& y=<49)

{
cout <<  y "reprobado" << endl; 
cout <<  y "sigue haci esforsandote" << endl; 
}
else (y>100&)
cout << y "fuera de rango"<< endl;
}